---
title: "Year sorting example"
description: "Nano groups posts by year."
date: "2023-12-31"
tags:
  - example
---

This post is to demonstrate the year sorting capabilities.
