---
title: "Draft example"
description: "Setting draft flag to true to hide this post."
date: "2022-12-31"
draft: false
tags:
  - example
---

This post also demonstrates the year sorting capabilities.

Try setting this file's metadata to `draft: true`.
